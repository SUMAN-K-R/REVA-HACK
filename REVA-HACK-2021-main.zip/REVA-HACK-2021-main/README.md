# REVA-HACK-2021
HACKATHON BY REVA UNIVERSITY 

Some 795 million people in the world do not have enough food to lead a healthy active life. That’s about one in nine people on earth. The vast majority of the world’s hungry people live in developing countries, where 12.9% of the population is undernourished. Poor nutrition causes nearly half (45%) deaths in children under five—3.1 million children each year. 
One out of six children—roughly 100 million—in developing countries is underweight. One in four of the world’s children are stunted. In developing countries the proportion can rise to one in three. 9.66 million primary school-age children attend classes hungry across the developing world, with 23 million in Africa alone.
This project is food redistribution is an enormously successful social innovation that tackles food waste and food poverty.

